
<?php $__env->startSection('content'); ?>
<div class="page page-center">
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-md-12 col-lg-12 text-center">
                <div class="d-inline-block">
                    <div class="card rounded-20 border-0">
                        <div class="card-body p-3">
                            <div id="qrcode"></div>
                        </div>
                    </div>
                    <div style="border: 1px dashed #636e72;" class="mx-3"></div>
                    <div class="card rounded-20 border-0">
                        <div class="card-body text-center pt-3">
                            <h2 class="fw-bold mb-3"><?php echo e($qrcode->title); ?></h2>
                            <div class="mt-3">
                                <h3 class="mb-0"><strong>Pasopati Mobile</strong></h3>
                                <p class="small">Copyright By Aplication Pasopati</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('assets/pus_dist/lib/jquery-qrcode/jquery-qrcode.js')); ?>"></script>
<script>
    let code = <?= json_encode($qrcode->code) ?>;

    $(document).ready(function() {
        generate();
        window.print();
    });

    const generate = () => {
        $("#qrcode").qrcode({
            size: 300,
            fill: '#0c0c0c',
            text: code,
            mode: 0,
        });
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hplbzcom/pasopati.hplbz18.com/resources/views/generate_qrcode/generate.blade.php ENDPATH**/ ?>