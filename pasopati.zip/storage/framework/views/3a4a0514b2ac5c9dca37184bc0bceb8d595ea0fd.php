<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Login - <?php echo e(env('APP_NAME')); ?></title>
    <!-- CSS files -->
    <link href="<?php echo e(asset('assets/dist/css/tabler.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/dist/css/tabler-flags.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/dist/css/tabler-payments.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/dist/css/tabler-vendors.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/dist/css/demo.min.css')); ?>" rel="stylesheet" />
</head>

<body class="border-top-wide border-primary d-flex flex-column">
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Libs JS -->
    <!-- Tabler Core -->
    <script src="<?php echo e(asset('assets/dist/js/tabler.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/js/demo.min.js')); ?>"></script>
    <!-- Jquery -->
    <script src="<?php echo e(asset('assets/pus_dist/lib/jquery/jquery.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html><?php /**PATH D:\Project-Koding\Laravel\Mas_Hari\sthira_yudha\menarmed\resources\views/layouts/app.blade.php ENDPATH**/ ?>