
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="w-100">
        <?php echo json_decode($artikel->artikel); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project-Koding\Laravel\Mas_Hari\armed_6\spartan\resources\views/artikel/view.blade.php ENDPATH**/ ?>