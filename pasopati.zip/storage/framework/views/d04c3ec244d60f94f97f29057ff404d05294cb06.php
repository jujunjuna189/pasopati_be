<form action="javascript:onSearch()" method="get">
    <div class="form-group">
        <input type="text" name="search" id="search" class="form-control" placeholder="Cari...">
    </div>
</form>
<?php $__env->startPush('script'); ?>
<script>
    const _inputSearch = 'input[name="search"]';
    const onSearch = () => {
        let searchData = $(_inputSearch).val();
        if (searchData != '') {
            location.href = "<?= url()->current() . '?filter[name]=' ?>" + searchData;
        } else {
            location.href = '<?= url()->current() ?>';
        }
    }
</script>
<?php $__env->stopPush(); ?><?php /**PATH /home/hplbzcom/menarmed.hplbz18.com/resources/views/components/field/field-search.blade.php ENDPATH**/ ?>