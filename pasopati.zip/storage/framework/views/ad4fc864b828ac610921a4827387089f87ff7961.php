<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <h1>Selamat Datang Di Aplikasi Spartan Mobile</h1>
                <p class="small">
                    Aplikasi pendataan Absensi, Perizinan, Gudang Senjata, dan Logistik
                </p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project-Koding\Laravel\Mas_Hari\spartan\resources\views/home.blade.php ENDPATH**/ ?>