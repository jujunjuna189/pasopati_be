
<?php $__env->startSection('content'); ?>
<div class="text-center">
    <h1>Opps</h1>
    <p>Halaman Belum tersedia <a href="#">Segera Hubungi Admin</a></p>
    <a href="<?php echo e(route('home')); ?>" class="btn bg-transparent" style="border-style: dashed; border-color: #9e9e9e;">
        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-arrow-left" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
            <line x1="5" y1="12" x2="19" y2="12"></line>
            <line x1="5" y1="12" x2="11" y2="18"></line>
            <line x1="5" y1="12" x2="11" y2="6"></line>
        </svg>
        Kembali
    </a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hplbzcom/menarmed.hplbz18.com/resources/views/error/404.blade.php ENDPATH**/ ?>