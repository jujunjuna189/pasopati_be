
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div id="calendar_event"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
<div class="modal modal-blur fade" id="modal-event" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Buat Event Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Tanggal</label>
                    <input type="text" class="form-control" name="date" readonly required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Nama Event</label>
                    <textarea class="form-control" rows="3" name="deskripsi" placeholder="..."></textarea>
                </div>
                <div>
                    <label class="form-label">Warna</label>
                    <select name="color" id="color" class="form-control">
                        <option value="success">Hijau</option>
                        <option value="primary">Biru</option>
                        <option value="danger">Merah</option>
                        <option value="warning">Oren</option>
                        <option value="dark">Hitam</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <a href="#" class="btn btn-link link-secondary" data-bs-dismiss="modal">
                    Batal
                </a>
                <a href="#" class="btn btn-primary ms-auto" onclick="saveEvent()">
                    <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                        <line x1="12" y1="5" x2="12" y2="19" />
                        <line x1="5" y1="12" x2="19" y2="12" />
                    </svg>
                    Simpan
                </a>
            </div>
        </div>
    </div>
</div>
<!-- Confirm delete -->
<div class="modal modal-blur fade" id="modal-confirm" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <div class="modal-status bg-danger"></div>
            <div class="modal-body text-center py-4">
                <span class="h2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-trash" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                        <line x1="4" y1="7" x2="20" y2="7"></line>
                        <line x1="10" y1="11" x2="10" y2="17"></line>
                        <line x1="14" y1="11" x2="14" y2="17"></line>
                        <path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"></path>
                        <path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"></path>
                    </svg>
                </span>
                <h3>Hapus Event ?</h3>
                <div class="text-muted">Apakah yakin ingin menghapus event ini ?</div>
            </div>
            <div class="modal-footer">
                <div class="w-100">
                    <div class="row">
                        <div class="col">
                            <a href="#" class="btn w-100" data-bs-dismiss="modal">
                                Batal
                            </a>
                        </div>
                        <div class="col">
                            <a href="#" class="btn btn-danger w-100" id="btn-delete-execute">
                                Hapus
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    let _events = <?= json_encode($event) ?>;
    let _modal_event = '#modal-event';
    let _modal_event_date = _modal_event + ' input[name="date"]';
    let _modal_event_deskripsi = _modal_event + ' textarea[name="deskripsi"]';
    let _modal_event_color = _modal_event + ' select[name="color"]';

    $(document).ready(function() {
        setEvent();
    });

    const setEvent = () => {
        let events = [];
        $.each(_events, function(i, val) {
            events.push({
                date: new Date(val.tanggal),
                eventName: val.event,
                className: "cursor-pointer badge bg-" + val.color,
                onclick(e, data) {
                    deleteEvent(val.id);
                },
                dateColor: "default"
            });
        });

        calendarEventInitialize(events);
    }

    const calendarEventInitialize = (events) => {
        var calendar = $("#calendar_event").calendarGC({
            dayBegin: 0,
            prevIcon: '&#x3c;',
            nextIcon: '&#x3e;',
            onPrevMonth: function(e) {
                console.log("prev");
                console.log(e)
            },
            onNextMonth: function(e) {
                console.log("next");
                console.log(e)
                console.log(calendar);
            },
            events: events,
            onclickDate: function(e, data) {
                let date = new Date(data.datejs);
                openModalEvent({
                    date: setDateFormat(date)
                });
            },
        });
    }

    const openModalEvent = ({
        date
    }) => {
        $(_modal_event).modal("show");
        $(_modal_event_date).val(date);
        $(_modal_event_deskripsi).val('');
    }

    const closeModal = () => {
        $(_modal_event).modal("hide");
    }

    const setDateFormat = (date) => {
        return date.getFullYear() + '-' + set_zero(date.getMonth() + 1) + '-' + set_zero(date.getDate());
    }

    const getModalData = () => {
        let tanggal = $(_modal_event_date).val();
        let event = $(_modal_event_deskripsi).val();
        let color = $(_modal_event_color).val();

        let data = {
            tanggal: tanggal,
            event: event,
            color: color,
        };

        return data;
    }

    const validateEventModal = () => {
        let data = getModalData();
        let validate = true;

        if (data.tanggal == '') {
            validate = false;
            notif('Tanggal harus diisi', 'error');
        }

        if (data.event == '') {
            validate = false;
            notif('Nama Event harus diisi', 'error');
        }

        return validate;
    }

    const saveEvent = () => {
        if (validateEventModal()) {
            let data = getModalData();
            requestServer({
                url: url + '/api/event/save',
                data: data,
                onLoader: true,
                onSuccess: function(value) {
                    close_swal(true, 'Berhasil tambah event', 'success');
                    closeModal();
                    reloadPage();
                },
            });
        }
    }

    const deleteEvent = (id) => {
        $('#modal-confirm').modal('show');
        $('#modal-confirm #btn-delete-execute').attr('onclick', 'deleteEventData(\'' + id + '\')');
    }

    const deleteEventData = (id) => {
        console.log(id);
        requestServer({
            url: url + '/api/event/delete',
            data: {
                id: id,
            },
            onLoader: true,
            onSuccess: function(value) {
                close_swal(true, 'Berhasil hapus event', 'success');
                closeModal();
                reloadPage();
            },
        });
    }

    const reloadPage = () => {
        setTimeout(function() {
            location.reload();
        }, 2000);
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project-Koding\Laravel\Mas_Hari\spartan\resources\views/event/index.blade.php ENDPATH**/ ?>